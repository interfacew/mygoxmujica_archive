import requests
import os
import json

def create_path(filepath):
    if not os.path.exists(f'data/{filepath}'):
        os.makedirs(f'data/{filepath}')

def store_l2d(tmp):
    print("下载和处理live2d文件")
    url = f'https://bestdori.com/assets/jp/live2d/chara/{tmp}_rip/buildData.asset'
    buildData = requests.get(url).content

    # with open(f'./data/{tmp}buildData.json', 'wb') as fb:
    #     fb.write(buildData)
    #     fb.close()

    data = json.loads(buildData)

    model_mark = {
        "version": "Sample 1.0.0",
        "layout": {
            "center_x": 0,
            "center_y": 0,
            "width": 2
        },
        "hit_areas_custom": {
            "head_x": [
                -0.25,
                1
            ],
            "head_y": [
                0.25,
                0.2
            ],
            "body_x": [
                -0.3,
                0.2
            ],
            "body_y": [
                0.3,
                -1.9
            ]
        }
    }

    ## 以下部分为照葫芦画瓢处理成webgal和live2dviewer可读json格式
    Base = data['Base']

    model = Base['model']
    fileName = model['fileName'].replace('.bytes', '')
    bundleName = model['bundleName']
    filePath = f"{bundleName}_rip"
    create_path(filePath)
    if not os.path.exists(f"data/{filePath}/{fileName}"):
        with open(f"data/{filePath}/{fileName}", 'wb') as fb:
            url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
            data = requests.get(url).content
            fb.write(data)
            fb.close()
    model_mark['model'] = f"{filePath}/{fileName}"

    physics = Base['physics']
    fileName = physics['fileName']
    bundleName = physics['bundleName']
    filePath = f"{bundleName}_rip"
    create_path(filePath)
    if not os.path.exists(f"data/{filePath}/{fileName}"):
        with open(f"data/{filePath}/{fileName}", 'wb') as fb:
            url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
            data = requests.get(url).content
            fb.write(data)
            fb.close()
    model_mark['physics'] = f"{filePath}/{fileName}"
    
    textures = Base['textures']
    model_mark['textures'] = []
    for texture in textures:
        fileName = texture['fileName']
        if not fileName.endswith('.png'):
            fileName = fileName + '.png'
        bundleName = texture['bundleName']
        filePath = f"{bundleName}_rip"
        create_path(filePath)
        if not os.path.exists(f"data/{filePath}/{fileName}"):
            with open(f"data/{filePath}/{fileName}", 'wb') as fb:
                url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
                data = requests.get(url).content
                fb.write(data)
                fb.close()
        model_mark['textures'].append(f"{filePath}/{fileName}")

    transition = Base['transition']
    fileName = transition['fileName']
    bundleName = transition['bundleName']
    filePath = f"{bundleName}_rip"
    create_path(filePath)
    if not os.path.exists(f"data/{filePath}/{fileName}"):
        with open(f"data/{filePath}/{fileName}", 'wb') as fb:
            url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
            data = requests.get(url).content
            fb.write(data)
            fb.close()

    motions = Base['motions']
    model_mark['motions'] = {}
    for motion in motions:
        fileName = motion['fileName'].replace('.bytes', '')
        bundleName = motion['bundleName']
        filePath = f"{bundleName}_rip"
        create_path(filePath)
        if not os.path.exists(f"data/{filePath}/{fileName}"):
            with open(f"data/{filePath}/{fileName}", 'wb') as fb:
                url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
                data = requests.get(url).content
                fb.write(data)
                fb.close()
        motion_name = fileName.split('.')[0]
        model_mark['motions'][motion_name] = [{"file": f"{filePath}/{fileName}"}]

    expressions = Base['expressions']
    model_mark['expressions'] = []
    for expression in expressions:
        fileName = expression['fileName']
        bundleName = expression['bundleName']
        filePath = f"{bundleName}_rip"
        create_path(filePath)
        if not os.path.exists(f"data/{filePath}/{fileName}"):
            with open(f"data/{filePath}/{fileName}", 'wb') as fb:
                url = f"https://bestdori.com/assets/jp/{bundleName}_rip/{fileName}"
                data = requests.get(url).content
                fb.write(data)
                fb.close()
        expression_name = fileName.split('.')[0]
        model_mark['expressions'].append({"name": expression_name, "file": f"{filePath}/{fileName}"})

    with open(f'./data/{tmp}model.json', 'w') as fb:
        fb.write(json.dumps(model_mark))
        fb.close()
    print("处理结束")

while True:
    l2d_name = input("输入要爬取处理的live2d：")
    store_l2d(l2d_name)