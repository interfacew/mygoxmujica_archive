本应用为 WebGAL 脚本辅助生成工具，使用方法见：https://www.bilibili.com/video/BV1yskbYqE1w/
后续更新版本见群：993616590