import os
for fileName in os.listdir(r"F:\galgame开发框架\Terre_MyGO_AveMujica_v12\public\games\第六集正式版\game\figure\mygo_avemujica_v6\小chuchu\live2d\chara\333_event_172_story_01_rip"):
    if fileName.endswith('mtn'):
        with open(fileName,mode='r',encoding='utf-8') as f:
            text = f.read()
            text = text.replace("PARAM_IMPORT=37","PARAM_IMPORT=1")
        with open(fileName,mode='w',encoding='utf-8') as f:
            f.write(text)

